/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static int ng0[] = {0, 0};
static unsigned int ng1[] = {0U, 0U, 0U, 0U};
static int ng2[] = {1, 0};
static const char *ng3 = "//vmware-host/Shared Folders/EE533/lab6_sp26/verilog/cpu_CMT.v";
static unsigned int ng4[] = {1U, 0U};
static unsigned int ng5[] = {0U, 0U};



static void C67_0(char *t0)
{
    char t3[16];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 8564U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 7720);
    t5 = (t2 + 32U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t4 + 4U);
    t8 = (t6 + 4U);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t6);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t8) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4U);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t20 = *((unsigned int *)t4);
    t21 = (~(t20));
    t22 = *((unsigned int *)t14);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t25, 16);

LAB16:    t26 = (t0 + 11668);
    t27 = (t26 + 32U);
    t28 = *((char **)t27);
    t29 = (t28 + 40U);
    t30 = *((char **)t29);
    xsi_vlog_bit_copy(t30, 0, t3, 0, 64);
    xsi_driver_vfirst_trans(t26, 0, 63);
    t31 = (t0 + 11560);
    *((int *)t31) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB8:    t18 = (t0 + 2324U);
    t19 = *((char **)t18);
    goto LAB9;

LAB10:    t18 = (t0 + 7996);
    t24 = (t18 + 32U);
    t25 = *((char **)t24);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 64, t19, 64, t25, 64);
    goto LAB16;

LAB14:    memcpy(t3, t19, 16);
    goto LAB16;

}

static void C136_1(char *t0)
{
    char t3[16];
    char t4[8];
    char t8[8];
    char t43[16];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;

LAB0:    t1 = (t0 + 8692U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4868);
    t5 = (t2 + 32U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng0)));
    memset(t8, 0, 8);
    t9 = (t8 + 4U);
    t10 = (t6 + 4U);
    t11 = (t7 + 4U);
    t12 = *((unsigned int *)t6);
    t13 = *((unsigned int *)t7);
    t14 = (t12 ^ t13);
    t15 = *((unsigned int *)t10);
    t16 = *((unsigned int *)t11);
    t17 = (t15 ^ t16);
    t18 = (t14 | t17);
    t19 = *((unsigned int *)t10);
    t20 = *((unsigned int *)t11);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB7;

LAB4:    if (t21 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t8) = 1;

LAB7:    memset(t4, 0, 8);
    t24 = (t4 + 4U);
    t25 = (t8 + 4U);
    t26 = *((unsigned int *)t25);
    t27 = (~(t26));
    t28 = *((unsigned int *)t8);
    t29 = (t28 & t27);
    t30 = (t29 & 1U);
    if (t30 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t25) != 0)
        goto LAB10;

LAB11:    t31 = (t4 + 4U);
    t32 = *((unsigned int *)t4);
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB12;

LAB13:    t36 = *((unsigned int *)t4);
    t37 = (~(t36));
    t38 = *((unsigned int *)t31);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t31) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t43, 16);

LAB20:    t53 = (t0 + 11704);
    t54 = (t53 + 32U);
    t55 = *((char **)t54);
    t56 = (t55 + 40U);
    t57 = *((char **)t56);
    xsi_vlog_bit_copy(t57, 0, t3, 0, 64);
    xsi_driver_vfirst_trans(t53, 0, 63);
    t58 = (t0 + 11568);
    *((int *)t58) = 1;

LAB1:    return;
LAB6:    *((unsigned int *)t8) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB11;

LAB12:    t35 = ((char*)((ng1)));
    goto LAB13;

LAB14:    t40 = (t0 + 5420);
    t41 = (t40 + 32U);
    t42 = *((char **)t41);
    t44 = (t0 + 5420);
    t45 = (t44 + 40U);
    t46 = *((char **)t45);
    t47 = (t0 + 5420);
    t48 = (t47 + 36U);
    t49 = *((char **)t48);
    t50 = (t0 + 4868);
    t51 = (t50 + 32U);
    t52 = *((char **)t51);
    xsi_vlog_generic_get_array_select_value(t43, 64, t42, t46, t49, 2, 1, t52, 5, 2);
    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 64, t35, 64, t43, 64);
    goto LAB20;

LAB18:    memcpy(t3, t35, 16);
    goto LAB20;

}

static void C137_2(char *t0)
{
    char t3[16];
    char t4[8];
    char t8[8];
    char t43[16];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;

LAB0:    t1 = (t0 + 8820U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4960);
    t5 = (t2 + 32U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng0)));
    memset(t8, 0, 8);
    t9 = (t8 + 4U);
    t10 = (t6 + 4U);
    t11 = (t7 + 4U);
    t12 = *((unsigned int *)t6);
    t13 = *((unsigned int *)t7);
    t14 = (t12 ^ t13);
    t15 = *((unsigned int *)t10);
    t16 = *((unsigned int *)t11);
    t17 = (t15 ^ t16);
    t18 = (t14 | t17);
    t19 = *((unsigned int *)t10);
    t20 = *((unsigned int *)t11);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB7;

LAB4:    if (t21 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t8) = 1;

LAB7:    memset(t4, 0, 8);
    t24 = (t4 + 4U);
    t25 = (t8 + 4U);
    t26 = *((unsigned int *)t25);
    t27 = (~(t26));
    t28 = *((unsigned int *)t8);
    t29 = (t28 & t27);
    t30 = (t29 & 1U);
    if (t30 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t25) != 0)
        goto LAB10;

LAB11:    t31 = (t4 + 4U);
    t32 = *((unsigned int *)t4);
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB12;

LAB13:    t36 = *((unsigned int *)t4);
    t37 = (~(t36));
    t38 = *((unsigned int *)t31);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t31) > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t4) > 0)
        goto LAB18;

LAB19:    memcpy(t3, t43, 16);

LAB20:    t53 = (t0 + 11740);
    t54 = (t53 + 32U);
    t55 = *((char **)t54);
    t56 = (t55 + 40U);
    t57 = *((char **)t56);
    xsi_vlog_bit_copy(t57, 0, t3, 0, 64);
    xsi_driver_vfirst_trans(t53, 0, 63);
    t58 = (t0 + 11576);
    *((int *)t58) = 1;

LAB1:    return;
LAB6:    *((unsigned int *)t8) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t4) = 1;
    goto LAB11;

LAB10:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB11;

LAB12:    t35 = ((char*)((ng1)));
    goto LAB13;

LAB14:    t40 = (t0 + 5420);
    t41 = (t40 + 32U);
    t42 = *((char **)t41);
    t44 = (t0 + 5420);
    t45 = (t44 + 40U);
    t46 = *((char **)t45);
    t47 = (t0 + 5420);
    t48 = (t47 + 36U);
    t49 = *((char **)t48);
    t50 = (t0 + 4960);
    t51 = (t50 + 32U);
    t52 = *((char **)t51);
    xsi_vlog_generic_get_array_select_value(t43, 64, t42, t46, t49, 2, 1, t52, 5, 2);
    goto LAB15;

LAB16:    xsi_vlog_unsigned_bit_combine(t3, 64, t35, 64, t43, 64);
    goto LAB20;

LAB18:    memcpy(t3, t35, 16);
    goto LAB20;

}

static void C143_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 8948U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 6616);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 11776);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    xsi_vlog_bit_copy(t9, 0, t4, 0, 64);
    xsi_driver_vfirst_trans(t5, 0, 63);
    t10 = (t0 + 11584);
    *((int *)t10) = 1;

LAB1:    return;
}

static void C144_4(char *t0)
{
    char t3[16];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 9076U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 5512);
    t5 = (t2 + 32U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t4 + 4U);
    t8 = (t6 + 4U);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t6);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t8) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4U);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t20 = *((unsigned int *)t4);
    t21 = (~(t20));
    t22 = *((unsigned int *)t14);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t25, 16);

LAB16:    t26 = (t0 + 11812);
    t27 = (t26 + 32U);
    t28 = *((char **)t27);
    t29 = (t28 + 40U);
    t30 = *((char **)t29);
    xsi_vlog_bit_copy(t30, 0, t3, 0, 64);
    xsi_driver_vfirst_trans(t26, 0, 63);
    t31 = (t0 + 11592);
    *((int *)t31) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB8:    t18 = (t0 + 2236U);
    t19 = *((char **)t18);
    goto LAB9;

LAB10:    t18 = (t0 + 6708);
    t24 = (t18 + 32U);
    t25 = *((char **)t24);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 64, t19, 64, t25, 64);
    goto LAB16;

LAB14:    memcpy(t3, t19, 16);
    goto LAB16;

}

static void C159_5(char *t0)
{
    char t5[8];
    char t17[8];
    char t26[8];
    char t34[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    int t58;
    int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t70;
    char *t71;
    unsigned int t72;
    unsigned int t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;

LAB0:    t1 = (t0 + 9204U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 5972);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    memset(t5, 0, 8);
    t6 = (t5 + 4U);
    t7 = (t4 + 4U);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t4);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t13 = (t5 + 4U);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t13);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB8;

LAB9:    memcpy(t34, t5, 8);

LAB10:    t66 = (t0 + 11848);
    t67 = (t66 + 32U);
    t68 = *((char **)t67);
    t69 = (t68 + 40U);
    t70 = *((char **)t69);
    t71 = (t70 + 4U);
    t72 = 1U;
    t73 = t72;
    t74 = (t34 + 4U);
    t75 = *((unsigned int *)t34);
    t72 = (t72 & t75);
    t76 = *((unsigned int *)t74);
    t73 = (t73 & t76);
    t77 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t77 & 4294967294U);
    t78 = *((unsigned int *)t70);
    *((unsigned int *)t70) = (t78 | t72);
    t79 = *((unsigned int *)t71);
    *((unsigned int *)t71) = (t79 & 4294967294U);
    t80 = *((unsigned int *)t71);
    *((unsigned int *)t71) = (t80 | t73);
    xsi_driver_vfirst_trans(t66, 0, 0);
    t81 = (t0 + 11600);
    *((int *)t81) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t5) = 1;
    goto LAB7;

LAB6:    *((unsigned int *)t5) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB7;

LAB8:    t18 = (t0 + 2060U);
    t19 = *((char **)t18);
    memset(t17, 0, 8);
    t18 = (t17 + 4U);
    t20 = (t19 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t19);
    t24 = (t23 & t22);
    t25 = (t24 & 1U);
    if (t25 != 0)
        goto LAB14;

LAB12:    if (*((unsigned int *)t20) == 0)
        goto LAB11;

LAB13:    *((unsigned int *)t17) = 1;
    *((unsigned int *)t18) = 1;

LAB14:    memset(t26, 0, 8);
    t27 = (t26 + 4U);
    t28 = (t17 + 4U);
    t29 = *((unsigned int *)t28);
    t30 = (~(t29));
    t31 = *((unsigned int *)t17);
    t32 = (t31 & t30);
    t33 = (t32 & 1U);
    if (t33 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t28) != 0)
        goto LAB17;

LAB18:    t35 = *((unsigned int *)t5);
    t36 = *((unsigned int *)t26);
    t37 = (t35 & t36);
    *((unsigned int *)t34) = t37;
    t38 = (t5 + 4U);
    t39 = (t26 + 4U);
    t40 = (t34 + 4U);
    t41 = *((unsigned int *)t38);
    t42 = *((unsigned int *)t39);
    t43 = (t41 | t42);
    *((unsigned int *)t40) = t43;
    t44 = *((unsigned int *)t40);
    t45 = (t44 != 0);
    if (t45 == 1)
        goto LAB19;

LAB20:
LAB21:    goto LAB10;

LAB11:    *((unsigned int *)t17) = 1;
    goto LAB14;

LAB15:    *((unsigned int *)t26) = 1;
    goto LAB18;

LAB17:    *((unsigned int *)t26) = 1;
    *((unsigned int *)t27) = 1;
    goto LAB18;

LAB19:    t46 = *((unsigned int *)t34);
    t47 = *((unsigned int *)t40);
    *((unsigned int *)t34) = (t46 | t47);
    t48 = (t5 + 4U);
    t49 = (t26 + 4U);
    t50 = *((unsigned int *)t5);
    t51 = (~(t50));
    t52 = *((unsigned int *)t48);
    t53 = (~(t52));
    t54 = *((unsigned int *)t26);
    t55 = (~(t54));
    t56 = *((unsigned int *)t49);
    t57 = (~(t56));
    t58 = (t51 & t53);
    t59 = (t55 & t57);
    t60 = (~(t58));
    t61 = (~(t59));
    t62 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t62 & t60);
    t63 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t63 & t61);
    t64 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t64 & t60);
    t65 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t65 & t61);
    goto LAB21;

}

static void C160_6(char *t0)
{
    char t6[8];
    char t7[8];
    char t17[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;

LAB0:    t1 = (t0 + 9332U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4132);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    xsi_vlog_unsigned_add(t6, 32, t4, 9, t5, 32);
    t8 = (t0 + 2236U);
    t9 = *((char **)t8);
    memset(t7, 0, 8);
    t8 = (t7 + 4U);
    t10 = (t9 + 4U);
    t11 = *((unsigned int *)t9);
    t12 = (t11 >> 0);
    *((unsigned int *)t7) = t12;
    t13 = *((unsigned int *)t10);
    t14 = (t13 >> 0);
    *((unsigned int *)t8) = t14;
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 & 511U);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 511U);
    memset(t17, 0, 8);
    xsi_vlog_unsigned_add(t17, 32, t6, 32, t7, 32);
    t18 = (t0 + 11884);
    t19 = (t18 + 32U);
    t20 = *((char **)t19);
    t21 = (t20 + 40U);
    t22 = *((char **)t21);
    t23 = (t22 + 4U);
    t24 = 1U;
    t25 = t24;
    t26 = (t17 + 4U);
    t27 = *((unsigned int *)t17);
    t24 = (t24 & t27);
    t28 = *((unsigned int *)t26);
    t25 = (t25 & t28);
    t29 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t29 & 4294967294U);
    t30 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t30 | t24);
    t31 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t31 & 4294967294U);
    t32 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t32 | t25);
    xsi_driver_vfirst_trans(t18, 0, 0);
    t33 = (t0 + 11608);
    *((int *)t33) = 1;

LAB1:    return;
}

static void A165_7(char *t0)
{
    char t3[8];
    char t20[8];
    char t21[8];
    char t30[8];
    char t85[8];
    char t86[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    int t69;
    int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    char *t84;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;
    char *t93;
    char *t94;
    char *t95;
    char *t96;
    unsigned int t97;
    int t98;
    char *t99;
    unsigned int t100;
    int t101;
    int t102;
    unsigned int t103;
    unsigned int t104;
    int t105;
    int t106;

LAB0:    t1 = (t0 + 9460U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(165, ng3);
    t2 = (t0 + 11616);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(166, ng3);

LAB5:    xsi_set_current_line(167, ng3);
    t4 = (t0 + 652U);
    t5 = *((char **)t4);
    memset(t3, 0, 8);
    t4 = (t3 + 4U);
    t6 = (t5 + 4U);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t6) == 0)
        goto LAB6;

LAB8:    *((unsigned int *)t3) = 1;
    *((unsigned int *)t4) = 1;

LAB9:    t12 = (t3 + 4U);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t3);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(187, ng3);

LAB14:    xsi_set_current_line(191, ng3);
    t2 = (t0 + 3820U);
    t4 = *((char **)t2);
    t2 = (t4 + 4U);
    t7 = *((unsigned int *)t2);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB15;

LAB16:    xsi_set_current_line(193, ng3);

LAB19:    xsi_set_current_line(194, ng3);
    t2 = (t0 + 4132);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng2)));
    memset(t3, 0, 8);
    xsi_vlog_unsigned_add(t3, 32, t5, 9, t6, 32);
    t12 = (t0 + 4132);
    xsi_vlogvar_generic_wait_assign_value(t12, t3, 2, 0, 0, 9, 0LL);

LAB17:    xsi_set_current_line(202, ng3);
    t2 = (t0 + 740U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4U);
    t5 = (t4 + 4U);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 21);
    *((unsigned int *)t3) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 21);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t11 & 31U);
    t13 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t13 & 31U);
    t6 = (t0 + 4868);
    xsi_vlogvar_generic_wait_assign_value(t6, t3, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(203, ng3);
    t2 = (t0 + 740U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4U);
    t5 = (t4 + 4U);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 16);
    *((unsigned int *)t3) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 16);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t11 & 31U);
    t13 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t13 & 31U);
    t6 = (t0 + 4960);
    xsi_vlogvar_generic_wait_assign_value(t6, t3, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(204, ng3);
    t2 = (t0 + 828U);
    t4 = *((char **)t2);
    memset(t20, 0, 8);
    t2 = (t20 + 4U);
    t5 = (t4 + 4U);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t4);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB20;

LAB21:    if (*((unsigned int *)t5) != 0)
        goto LAB22;

LAB23:    t6 = (t20 + 4U);
    t13 = *((unsigned int *)t20);
    t14 = *((unsigned int *)t6);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB24;

LAB25:    t26 = *((unsigned int *)t20);
    t27 = (~(t26));
    t28 = *((unsigned int *)t6);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t6) > 0)
        goto LAB28;

LAB29:    if (*((unsigned int *)t20) > 0)
        goto LAB30;

LAB31:    memcpy(t3, t30, 8);

LAB32:    t40 = (t0 + 5052);
    xsi_vlogvar_generic_wait_assign_value(t40, t3, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(206, ng3);
    t2 = (t0 + 740U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4U);
    t5 = (t4 + 4U);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 0);
    *((unsigned int *)t3) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t11 & 65535U);
    t13 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t13 & 65535U);
    t6 = (t0 + 5236);
    xsi_vlogvar_generic_wait_assign_value(t6, t3, 2, 0, 0, 16, 0LL);
    xsi_set_current_line(207, ng3);
    t2 = (t0 + 740U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t3 + 4U);
    t5 = (t4 + 4U);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 0);
    *((unsigned int *)t3) = t8;
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 0);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t11 & 15U);
    t13 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t13 & 15U);
    t6 = (t0 + 5144);
    xsi_vlogvar_generic_wait_assign_value(t6, t3, 2, 0, 0, 4, 0LL);
    xsi_set_current_line(210, ng3);
    t2 = (t0 + 916U);
    t4 = *((char **)t2);
    t2 = (t0 + 4224);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(211, ng3);
    t2 = (t0 + 1004U);
    t4 = *((char **)t2);
    t2 = (t0 + 4316);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(212, ng3);
    t2 = (t0 + 1092U);
    t4 = *((char **)t2);
    t2 = (t0 + 4408);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(213, ng3);
    t2 = (t0 + 1180U);
    t4 = *((char **)t2);
    t2 = (t0 + 4500);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(214, ng3);
    t2 = (t0 + 1268U);
    t4 = *((char **)t2);
    t2 = (t0 + 4592);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(215, ng3);
    t2 = (t0 + 1356U);
    t4 = *((char **)t2);
    t2 = (t0 + 4684);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(216, ng3);
    t2 = (t0 + 1532U);
    t4 = *((char **)t2);
    t2 = (t0 + 1444U);
    t5 = *((char **)t2);
    xsi_vlogtype_concat(t3, 2, 2, 2U, t5, 1, t4, 1);
    t2 = (t0 + 4776);
    xsi_vlogvar_generic_wait_assign_value(t2, t3, 2, 0, 0, 2, 0LL);
    xsi_set_current_line(217, ng3);
    t2 = (t0 + 740U);
    t4 = *((char **)t2);
    t2 = (t0 + 5328);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 32, 0LL);
    xsi_set_current_line(222, ng3);
    t2 = (t0 + 7812);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    memset(t3, 0, 8);
    t6 = (t3 + 4U);
    t12 = (t5 + 4U);
    t7 = *((unsigned int *)t12);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t12) != 0)
        goto LAB35;

LAB36:    t18 = (t3 + 4U);
    t13 = *((unsigned int *)t3);
    t14 = *((unsigned int *)t18);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB37;

LAB38:    memcpy(t30, t3, 8);

LAB39:    t77 = (t30 + 4U);
    t78 = *((unsigned int *)t77);
    t79 = (~(t78));
    t80 = *((unsigned int *)t30);
    t81 = (t80 & t79);
    t82 = (t81 != 0);
    if (t82 > 0)
        goto LAB51;

LAB52:
LAB53:    xsi_set_current_line(228, ng3);
    t2 = (t0 + 6892);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7720);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(229, ng3);
    t2 = (t0 + 7444);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7996);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(230, ng3);
    t2 = (t0 + 7352);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7904);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(231, ng3);
    t2 = (t0 + 6984);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7812);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(232, ng3);
    t2 = (t0 + 7628);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 8088);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 32, 0LL);
    xsi_set_current_line(237, ng3);
    t2 = (t0 + 1972U);
    t4 = *((char **)t2);
    t2 = (t0 + 7444);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(238, ng3);
    t2 = (t0 + 6708);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7536);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(239, ng3);
    t2 = (t0 + 5604);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6892);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(240, ng3);
    t2 = (t0 + 5696);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6984);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(241, ng3);
    t2 = (t0 + 5788);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7076);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(242, ng3);
    t2 = (t0 + 5880);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7168);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(243, ng3);
    t2 = (t0 + 5972);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7260);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(244, ng3);
    t2 = (t0 + 6340);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7352);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(245, ng3);
    t2 = (t0 + 6800);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 7628);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 32, 0LL);
    xsi_set_current_line(250, ng3);
    t2 = (t0 + 1620U);
    t4 = *((char **)t2);
    t2 = (t0 + 6616);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(251, ng3);
    t2 = (t0 + 1708U);
    t4 = *((char **)t2);
    t2 = (t0 + 6708);
    xsi_vlogvar_generic_wait_assign_value(t2, t4, 2, 0, 0, 64, 0LL);
    xsi_set_current_line(252, ng3);
    t2 = (t0 + 4868);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6156);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(253, ng3);
    t2 = (t0 + 4960);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6248);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(254, ng3);
    t2 = (t0 + 5052);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6340);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 5, 0LL);
    xsi_set_current_line(255, ng3);
    t2 = (t0 + 5236);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6524);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 16, 0LL);
    xsi_set_current_line(256, ng3);
    t2 = (t0 + 5144);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6432);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 4, 0LL);
    xsi_set_current_line(258, ng3);
    t2 = (t0 + 4224);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5512);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(259, ng3);
    t2 = (t0 + 4316);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5604);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(260, ng3);
    t2 = (t0 + 4408);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5696);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(261, ng3);
    t2 = (t0 + 4500);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5788);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(262, ng3);
    t2 = (t0 + 4592);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5880);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(263, ng3);
    t2 = (t0 + 4684);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 5972);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 1, 0LL);
    xsi_set_current_line(264, ng3);
    t2 = (t0 + 4776);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6064);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 2, 0LL);
    xsi_set_current_line(265, ng3);
    t2 = (t0 + 5328);
    t4 = (t2 + 32U);
    t5 = *((char **)t4);
    t6 = (t0 + 6800);
    xsi_vlogvar_generic_wait_assign_value(t6, t5, 2, 0, 0, 32, 0LL);

LAB12:    goto LAB2;

LAB6:    *((unsigned int *)t3) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(168, ng3);

LAB13:    xsi_set_current_line(169, ng3);
    t18 = ((char*)((ng0)));
    t19 = (t0 + 4132);
    xsi_vlogvar_generic_wait_assign_value(t19, t18, 1, 0, 0, 9, 0LL);
    xsi_set_current_line(171, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4224);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(171, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4316);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(171, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4408);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(172, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4500);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(172, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4592);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(172, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4684);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(173, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 4776);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 2, 0LL);
    xsi_set_current_line(173, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5328);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 32, 0LL);
    xsi_set_current_line(175, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5512);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(175, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5604);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(175, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5696);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(176, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5788);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(176, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5880);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(176, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 5972);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(177, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 6064);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 2, 0LL);
    xsi_set_current_line(177, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 6800);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 32, 0LL);
    xsi_set_current_line(179, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 6892);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(179, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 6984);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(180, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 7076);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(180, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 7168);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(181, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 7628);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 32, 0LL);
    xsi_set_current_line(183, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 7720);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(183, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 7812);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 1, 0LL);
    xsi_set_current_line(184, ng3);
    t2 = ((char*)((ng0)));
    t4 = (t0 + 8088);
    xsi_vlogvar_generic_wait_assign_value(t4, t2, 1, 0, 0, 32, 0LL);
    goto LAB12;

LAB15:    xsi_set_current_line(191, ng3);

LAB18:    xsi_set_current_line(192, ng3);
    t5 = (t0 + 3908U);
    t6 = *((char **)t5);
    memcpy(t3, t6, 8);
    t5 = (t0 + 4132);
    xsi_vlogvar_generic_wait_assign_value(t5, t3, 2, 0, 0, 9, 0LL);
    goto LAB17;

LAB20:    *((unsigned int *)t20) = 1;
    goto LAB23;

LAB22:    *((unsigned int *)t20) = 1;
    *((unsigned int *)t2) = 1;
    goto LAB23;

LAB24:    t12 = (t0 + 740U);
    t18 = *((char **)t12);
    memset(t21, 0, 8);
    t12 = (t21 + 4U);
    t19 = (t18 + 4U);
    t16 = *((unsigned int *)t18);
    t17 = (t16 >> 11);
    *((unsigned int *)t21) = t17;
    t22 = *((unsigned int *)t19);
    t23 = (t22 >> 11);
    *((unsigned int *)t12) = t23;
    t24 = *((unsigned int *)t21);
    *((unsigned int *)t21) = (t24 & 31U);
    t25 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t25 & 31U);
    goto LAB25;

LAB26:    t31 = (t0 + 740U);
    t32 = *((char **)t31);
    memset(t30, 0, 8);
    t31 = (t30 + 4U);
    t33 = (t32 + 4U);
    t34 = *((unsigned int *)t32);
    t35 = (t34 >> 16);
    *((unsigned int *)t30) = t35;
    t36 = *((unsigned int *)t33);
    t37 = (t36 >> 16);
    *((unsigned int *)t31) = t37;
    t38 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t38 & 31U);
    t39 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t39 & 31U);
    goto LAB27;

LAB28:    xsi_vlog_unsigned_bit_combine(t3, 5, t21, 5, t30, 5);
    goto LAB32;

LAB30:    memcpy(t3, t21, 8);
    goto LAB32;

LAB33:    *((unsigned int *)t3) = 1;
    goto LAB36;

LAB35:    *((unsigned int *)t3) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB36;

LAB37:    t19 = (t0 + 7904);
    t31 = (t19 + 32U);
    t32 = *((char **)t31);
    t33 = ((char*)((ng0)));
    memset(t20, 0, 8);
    t40 = (t20 + 4U);
    t41 = (t32 + 4U);
    t42 = (t33 + 4U);
    t16 = *((unsigned int *)t32);
    t17 = *((unsigned int *)t33);
    t22 = (t16 ^ t17);
    t23 = *((unsigned int *)t41);
    t24 = *((unsigned int *)t42);
    t25 = (t23 ^ t24);
    t26 = (t22 | t25);
    t27 = *((unsigned int *)t41);
    t28 = *((unsigned int *)t42);
    t29 = (t27 | t28);
    t34 = (~(t29));
    t35 = (t26 & t34);
    if (t35 != 0)
        goto LAB41;

LAB40:    if (t29 != 0)
        goto LAB42;

LAB43:    memset(t21, 0, 8);
    t43 = (t21 + 4U);
    t44 = (t20 + 4U);
    t36 = *((unsigned int *)t44);
    t37 = (~(t36));
    t38 = *((unsigned int *)t20);
    t39 = (t38 & t37);
    t45 = (t39 & 1U);
    if (t45 != 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t44) != 0)
        goto LAB46;

LAB47:    t46 = *((unsigned int *)t3);
    t47 = *((unsigned int *)t21);
    t48 = (t46 & t47);
    *((unsigned int *)t30) = t48;
    t49 = (t3 + 4U);
    t50 = (t21 + 4U);
    t51 = (t30 + 4U);
    t52 = *((unsigned int *)t49);
    t53 = *((unsigned int *)t50);
    t54 = (t52 | t53);
    *((unsigned int *)t51) = t54;
    t55 = *((unsigned int *)t51);
    t56 = (t55 != 0);
    if (t56 == 1)
        goto LAB48;

LAB49:
LAB50:    goto LAB39;

LAB41:    *((unsigned int *)t20) = 1;
    goto LAB43;

LAB42:    *((unsigned int *)t20) = 1;
    *((unsigned int *)t40) = 1;
    goto LAB43;

LAB44:    *((unsigned int *)t21) = 1;
    goto LAB47;

LAB46:    *((unsigned int *)t21) = 1;
    *((unsigned int *)t43) = 1;
    goto LAB47;

LAB48:    t57 = *((unsigned int *)t30);
    t58 = *((unsigned int *)t51);
    *((unsigned int *)t30) = (t57 | t58);
    t59 = (t3 + 4U);
    t60 = (t21 + 4U);
    t61 = *((unsigned int *)t3);
    t62 = (~(t61));
    t63 = *((unsigned int *)t59);
    t64 = (~(t63));
    t65 = *((unsigned int *)t21);
    t66 = (~(t65));
    t67 = *((unsigned int *)t60);
    t68 = (~(t67));
    t69 = (t62 & t64);
    t70 = (t66 & t68);
    t71 = (~(t69));
    t72 = (~(t70));
    t73 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t73 & t71);
    t74 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t74 & t72);
    t75 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t75 & t71);
    t76 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t76 & t72);
    goto LAB50;

LAB51:    xsi_set_current_line(223, ng3);
    t83 = (t0 + 2412U);
    t84 = *((char **)t83);
    t83 = (t0 + 5420);
    t87 = (t0 + 5420);
    t88 = (t87 + 40U);
    t89 = *((char **)t88);
    t90 = (t0 + 5420);
    t91 = (t90 + 36U);
    t92 = *((char **)t91);
    t93 = (t0 + 7904);
    t94 = (t93 + 32U);
    t95 = *((char **)t94);
    xsi_vlog_generic_convert_array_indices(t85, t86, t89, t92, 2, 1, t95, 5, 2);
    t96 = (t85 + 4U);
    t97 = *((unsigned int *)t96);
    t98 = (!(t97));
    t99 = (t86 + 4U);
    t100 = *((unsigned int *)t99);
    t101 = (!(t100));
    t102 = (t98 && t101);
    if (t102 == 1)
        goto LAB54;

LAB55:    goto LAB53;

LAB54:    t103 = *((unsigned int *)t85);
    t104 = *((unsigned int *)t86);
    t105 = (t103 - t104);
    t106 = (t105 + 1);
    xsi_vlogvar_generic_wait_assign_value(t83, t84, 2, 0, *((unsigned int *)t86), t106, 0LL);
    goto LAB55;

}

static void implSig1_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 9588U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng4)));
    t3 = (t0 + 11920);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig2_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 9716U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 11956);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 511U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294966784U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294966784U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 8);

LAB1:    return;
}

static void implSig3_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 9844U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 11992);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig4_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 9972U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12028);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    memcpy(t7, t2, 8);
    xsi_driver_vfirst_trans(t3, 0, 31);

LAB1:    return;
}

static void implSig5_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10100U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12064);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig6_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10228U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12100);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig7_execute(char *t0)
{
    char t8[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;

LAB0:    t1 = (t0 + 10356U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 7076);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 7168);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t7);
    t11 = (t9 | t10);
    *((unsigned int *)t8) = t11;
    t12 = (t4 + 4U);
    t13 = (t7 + 4U);
    t14 = (t8 + 4U);
    t15 = *((unsigned int *)t12);
    t16 = *((unsigned int *)t13);
    t17 = (t15 | t16);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t14);
    t19 = (t18 != 0);
    if (t19 == 1)
        goto LAB4;

LAB5:
LAB6:    t36 = (t0 + 12136);
    t37 = (t36 + 32U);
    t38 = *((char **)t37);
    t39 = (t38 + 40U);
    t40 = *((char **)t39);
    t41 = (t40 + 4U);
    t42 = 1U;
    t43 = t42;
    t44 = (t8 + 4U);
    t45 = *((unsigned int *)t8);
    t42 = (t42 & t45);
    t46 = *((unsigned int *)t44);
    t43 = (t43 & t46);
    t47 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t47 & 4294967294U);
    t48 = *((unsigned int *)t40);
    *((unsigned int *)t40) = (t48 | t42);
    t49 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t49 & 4294967294U);
    t50 = *((unsigned int *)t41);
    *((unsigned int *)t41) = (t50 | t43);
    xsi_driver_vfirst_trans(t36, 0, 0);
    t51 = (t0 + 11624);
    *((int *)t51) = 1;

LAB1:    return;
LAB4:    t20 = *((unsigned int *)t8);
    t21 = *((unsigned int *)t14);
    *((unsigned int *)t8) = (t20 | t21);
    t22 = (t4 + 4U);
    t23 = (t7 + 4U);
    t24 = *((unsigned int *)t22);
    t25 = (~(t24));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = *((unsigned int *)t23);
    t29 = (~(t28));
    t30 = *((unsigned int *)t7);
    t31 = (t30 & t29);
    t32 = (~(t27));
    t33 = (~(t31));
    t34 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t34 & t32);
    t35 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t35 & t33);
    goto LAB6;

}

static void implSig8_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10484U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12172);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 255U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967040U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967040U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 7);

LAB1:    return;
}

static void implSig9_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10612U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12208);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig10_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t1 = (t0 + 10740U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng1)));
    t3 = (t0 + 12244);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    xsi_vlog_bit_copy(t7, 0, t2, 0, 64);
    xsi_driver_vfirst_trans(t3, 0, 63);

LAB1:    return;
}

static void implSig11_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10868U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12280);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig12_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 10996U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12316);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 1U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967294U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967294U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 0);

LAB1:    return;
}

static void implSig13_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 11124U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12352);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 255U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967040U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967040U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 7);

LAB1:    return;
}

static void implSig14_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 11252U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12388);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 127U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967168U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967168U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 6);

LAB1:    return;
}

static void implSig15_execute(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;

LAB0:    t1 = (t0 + 11380U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = ((char*)((ng5)));
    t3 = (t0 + 12424);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    t8 = (t7 + 4U);
    t9 = 127U;
    t10 = t9;
    t11 = (t2 + 4U);
    t12 = *((unsigned int *)t2);
    t9 = (t9 & t12);
    t13 = *((unsigned int *)t11);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t14 & 4294967168U);
    t15 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t15 | t9);
    t16 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t16 & 4294967168U);
    t17 = *((unsigned int *)t8);
    *((unsigned int *)t8) = (t17 | t10);
    xsi_driver_vfirst_trans(t3, 0, 6);

LAB1:    return;
}


extern void work_m_00000000000346600079_2374664768_init()
{
	static char *pe[] = {(void *)C67_0,(void *)C136_1,(void *)C137_2,(void *)C143_3,(void *)C144_4,(void *)C159_5,(void *)C160_6,(void *)A165_7,(void *)implSig1_execute,(void *)implSig2_execute,(void *)implSig3_execute,(void *)implSig4_execute,(void *)implSig5_execute,(void *)implSig6_execute,(void *)implSig7_execute,(void *)implSig8_execute,(void *)implSig9_execute,(void *)implSig10_execute,(void *)implSig11_execute,(void *)implSig12_execute,(void *)implSig13_execute,(void *)implSig14_execute,(void *)implSig15_execute};
	xsi_register_didat("work_m_00000000000346600079_2374664768", "isim/_tmp/work/m_00000000000346600079_2374664768.didat");
	xsi_register_executes(pe);
}
