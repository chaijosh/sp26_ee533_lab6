/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//vmware-host/Shared Folders/EE533/lab6_sp26/verilog/cmt_test1.v";
static int ng1[] = {0, 0};
static const char *ng2 = "Starting Testbench for basic CPU operations...";
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static const char *ng5 = "Reset released at time %0t";
static const char *ng6 = "Initializing source registers...";
static unsigned int ng7[] = {0U, 0U, 0U, 0U};
static int ng8[] = {1, 0};
static unsigned int ng9[] = {10U, 0U, 0U, 0U};
static int ng10[] = {2, 0};
static int ng11[] = {10, 0};
static unsigned int ng12[] = {5U, 0U, 0U, 0U};
static int ng13[] = {11, 0};
static int ng14[] = {20, 0};
static unsigned int ng15[] = {9U, 0U, 0U, 0U};
static int ng16[] = {21, 0};
static unsigned int ng17[] = {6U, 0U, 0U, 0U};
static int ng18[] = {22, 0};



static void I39_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;

LAB0:    t1 = (t0 + 1344U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);

LAB4:    xsi_set_current_line(40, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 776);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(41, ng0);

LAB5:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 1260);
    xsi_process_wait(t2, 100000000LL);
    *((char **)t1) = &&LAB6;

LAB1:    return;
LAB6:    xsi_set_current_line(41, ng0);
    t3 = (t0 + 776);
    t5 = (t3 + 32U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t7 = (t4 + 4U);
    t8 = (t6 + 4U);
    t9 = *((unsigned int *)t6);
    t10 = (~(t9));
    *((unsigned int *)t4) = t10;
    *((unsigned int *)t7) = 0;
    if (*((unsigned int *)t8) != 0)
        goto LAB8;

LAB7:    t15 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t15 & 1U);
    t16 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t16 & 1U);
    t17 = (t0 + 776);
    xsi_vlogvar_assign_value(t17, t4, 0, 0, 1);
    goto LAB5;

LAB8:    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t8);
    *((unsigned int *)t4) = (t11 | t12);
    t13 = *((unsigned int *)t7);
    t14 = *((unsigned int *)t8);
    *((unsigned int *)t7) = (t13 | t14);
    goto LAB7;

LAB9:    goto LAB1;

}

static void I44_1(char *t0)
{
    char t4[16];
    char t6[8];
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned int t18;
    int t19;
    char *t20;
    unsigned int t21;
    int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;
    int t26;
    int t27;

LAB0:    t1 = (t0 + 1472U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(44, ng0);

LAB4:    xsi_set_current_line(45, ng0);
    xsi_vlogfile_write(1, 0, ng2, 1, t0);
    xsi_set_current_line(48, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 868);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(49, ng0);
    t2 = (t0 + 1388);
    xsi_process_wait(t2, 1000000000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 868);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(51, ng0);
    t2 = xsi_vlog_time(t4, 1000000.000000000, 1000.000000000000);
    xsi_vlogfile_write(1, 0, ng5, 2, t0, (char)118, t4, 64);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1388);
    xsi_process_wait(t2, 200000000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(59, ng0);
    xsi_vlogfile_write(1, 0, ng6, 1, t0);
    xsi_set_current_line(60, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2840);
    t5 = *((char **)t3);
    t8 = (t0 + 2860);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 2880);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng8)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB7;

LAB8:    xsi_set_current_line(61, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2900);
    t5 = *((char **)t3);
    t8 = (t0 + 2920);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 2940);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng10)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB9;

LAB10:    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2960);
    t5 = *((char **)t3);
    t8 = (t0 + 2980);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 3000);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng11)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB11;

LAB12:    xsi_set_current_line(63, ng0);
    t2 = ((char*)((ng12)));
    t3 = (t0 + 3020);
    t5 = *((char **)t3);
    t8 = (t0 + 3040);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 3060);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng13)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB13;

LAB14:    xsi_set_current_line(64, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 3080);
    t5 = *((char **)t3);
    t8 = (t0 + 3100);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 3120);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng14)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB15;

LAB16:    xsi_set_current_line(65, ng0);
    t2 = ((char*)((ng15)));
    t3 = (t0 + 3140);
    t5 = *((char **)t3);
    t8 = (t0 + 3160);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 3180);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng16)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB17;

LAB18:    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng17)));
    t3 = (t0 + 3200);
    t5 = *((char **)t3);
    t8 = (t0 + 3220);
    t9 = *((char **)t8);
    t10 = ((((char*)(t9))) + 40U);
    t11 = *((char **)t10);
    t12 = (t0 + 3240);
    t13 = *((char **)t12);
    t14 = ((((char*)(t13))) + 36U);
    t15 = *((char **)t14);
    t16 = ((char*)((ng18)));
    xsi_vlog_generic_convert_array_indices(t6, t7, t11, t15, 2, 1, t16, 32, 1);
    t17 = (t6 + 4U);
    t18 = *((unsigned int *)t17);
    t19 = (!(t18));
    t20 = (t7 + 4U);
    t21 = *((unsigned int *)t20);
    t22 = (!(t21));
    t23 = (t19 && t22);
    if (t23 == 1)
        goto LAB19;

LAB20:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1388);
    xsi_process_wait(t2, 4000000000LL);
    *((char **)t1) = &&LAB21;
    goto LAB1;

LAB7:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB8;

LAB9:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB10;

LAB11:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB12;

LAB13:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB14;

LAB15:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB16;

LAB17:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB18;

LAB19:    t24 = *((unsigned int *)t6);
    t25 = *((unsigned int *)t7);
    t26 = (t24 - t25);
    t27 = (t26 + 1);
    xsi_vlogvar_assign_value(((char*)(t5)), t2, 0, *((unsigned int *)t7), t27);
    goto LAB20;

LAB21:    goto LAB1;

}


extern void work_m_00000000001432467755_0734845877_init()
{
	static char *pe[] = {(void *)I39_0,(void *)I44_1};
	xsi_register_didat("work_m_00000000001432467755_0734845877", "isim/_tmp/work/m_00000000001432467755_0734845877.didat");
	xsi_register_executes(pe);
}
